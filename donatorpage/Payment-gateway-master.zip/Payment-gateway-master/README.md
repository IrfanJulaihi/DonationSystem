# Payment-gateway
PayUMoney
Download the files(payuform,success,failure).
Save them to your htdocs or www folder.
Now edit form page, edit the success page and failure page url as stored in your system(using ftp:// or http://).
Run the form page in browser and fill all mandatory field. add any text as product info.
On submit,it redirrects to test payumoney site.
Now using a test debit card fill the details and pay the bill.
Success page arrives if your payment is successfull, else failure page arrives.
