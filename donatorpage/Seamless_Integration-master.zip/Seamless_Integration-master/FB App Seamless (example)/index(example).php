<!DOCTYPE html>
<html lang="en">
<head>
<title>FB Seamless Integration</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="./molpay_facebook_seamless.js"></script>
<script src="https://www.onlinepayment.com.my/MOLPay/API/seamless/latest/js/MOLPay_seamless.deco.js"></script>
</head>
<body>
<div class="container-fluid">
  <div class="row">
	  <div class="col-md-offset-3 col-md-6">
		&nbsp;
	  </div>
	  <div class="col-md-offset-3 col-md-6" id="molpay_btn">
		<!--<button type="button" id="myPay" class="btn btn-primary btn-lg" data-toggle="molpayseamless" data-mpsmerchantid="molpaymerchant" data-mpschannel="maybank2u" data-mpsamount="1.20" data-mpsorderid="TEST1139669863" data-mpsbill_name="" >Pay by Maybank2u</button>-->
	  </div>
  </div>
</div>
</body>
</html>
